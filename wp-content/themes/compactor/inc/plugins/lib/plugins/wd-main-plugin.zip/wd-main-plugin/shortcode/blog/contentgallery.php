
<article <?php post_class("wd-post wd-post--gallery ".$post_class); ?> >
	<?php if($show_thumbnail == 'yes') { ?>
		<div class="wd-post__thumbnail">
			<div class="wd-gallery-images-holder clearfix wd-post__thumbnail--gallery">
				<?php
				$portfolio_image_gallery_val = get_post_meta(get_the_ID(), 'wd_portfolio-image-gallery', true);
				if ($portfolio_image_gallery_val != '') $portfolio_image_gallery_array = explode(',', $portfolio_image_gallery_val);

				if (isset($portfolio_image_gallery_array) && count($portfolio_image_gallery_array) != 0):
					foreach ($portfolio_image_gallery_array as $gimg_id):
						echo   wp_get_attachment_image( $gimg_id, 'compactor_blog-thumb', false );
					endforeach;
				endif;
				?>
			</div>

		</div>
	<?php } ?>
  <div class="wd-post__content">

	  <?php if ($show_category == 'yes') { ?>
        <div class="wd-post__categories"><?php  the_category(); ?></div>
	  <?php } ?>

    <<?php echo $headeing_tag ?> class="wd-post__title">
    <a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a>
  </<?php echo $headeing_tag ?>>

	<?php if ($show_meta == 'yes') { ?>
      <ul class="wd-post__meta clearfix">
        <li class="wd-post__date">
			<?php echo get_the_date(); ?>
        </li>
        <li class="wd-post__author">
			<?php echo esc_html__('By:', 'compactor'); the_author() ?>
        </li>
        <li class="wd-post__comments">
			<?php comments_number('no comments', 'one comment', '% comments'); ?>
        </li>
      </ul>
	<?php } ?>

  <div class="wd-post__body">
    <p><?php echo wp_trim_words(get_the_content(), 15); ?></p>
  </div>

	<?php if ($show_readmore == 'yes') { ?>
      <div class="wd-post__read-more">
        <a href="<?php esc_url(the_permalink()); ?>">
			<?php echo esc_html__('Read More', 'compactor'); ?>
          <img src="<?php echo get_template_directory_uri() . "/images/more.svg" ?>" alt="icon">
        </a>
      </div>
	<?php } ?>

  </div>
</article>