
		<article <?php post_class("wd-post wd-post--link ".$post_class); ?>>
			<div class="wd-post__body">
				<i class="fa fa-link"></i> <?php the_content();  ?>
			</div>
			</article>